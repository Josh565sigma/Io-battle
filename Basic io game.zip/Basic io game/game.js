const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Set canvas size
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// Player properties
const player = {
  x: canvas.width / 2,
  y: canvas.height / 2,
  radius: 20,
  color: 'blue',
  speed: 5,
  dx: 0,
  dy: 0
};

// Food properties
const food = {
  x: Math.random() * canvas.width,
  y: Math.random() * canvas.height,
  radius: 10,
  color: 'red'
};

// Resize canvas when the window is resized
window.addEventListener('resize', () => {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
});

// Move the player
function movePlayer() {
  player.x += player.dx;
  player.y += player.dy;

  // Prevent the player from going off-screen
  if (player.x < 0) player.x = 0;
  if (player.x > canvas.width) player.x = canvas.width;
  if (player.y < 0) player.y = 0;
  if (player.y > canvas.height) player.y = canvas.height;
}

// Draw the player
function drawPlayer() {
  ctx.beginPath();
  ctx.arc(player.x, player.y, player.radius, 0, Math.PI * 2);
  ctx.fillStyle = player.color;
  ctx.fill();
  ctx.closePath();
}

// Draw the food
function drawFood() {
  ctx.beginPath();
  ctx.arc(food.x, food.y, food.radius, 0, Math.PI * 2);
  ctx.fillStyle = food.color;
  ctx.fill();
  ctx.closePath();
}

// Check for collision between player and food
function checkCollision() {
  const dx = player.x - food.x;
  const dy = player.y - food.y;
  const distance = Math.sqrt(dx * dx + dy * dy);

  // If the player touches the food
  if (distance < player.radius + food.radius) {
    // Increase player size
    player.radius += 5;

    // Reposition food
    food.x = Math.random() * canvas.width;
    food.y = Math.random() * canvas.height;
  }
}

// Handle player input (keyboard)
function handleInput() {
  if (keys['ArrowUp']) player.dy = -player.speed;
  else if (keys['ArrowDown']) player.dy = player.speed;
  else player.dy = 0;

  if (keys['ArrowLeft']) player.dx = -player.speed;
  else if (keys['ArrowRight']) player.dx = player.speed;
  else player.dx = 0;
}

// Key press tracking
const keys = {};
window.addEventListener('keydown', (event) => {
  keys[event.key] = true;
});
window.addEventListener('keyup', (event) => {
  keys[event.key] = false;
});

// Game loop function
function gameLoop() {
  // Clear the canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Update game elements
  movePlayer();
  handleInput();
  checkCollision();

  // Draw game elements
  drawPlayer();
  drawFood();

  // Keep the game running
  requestAnimationFrame(gameLoop);
}

// Start the game
gameLoop();